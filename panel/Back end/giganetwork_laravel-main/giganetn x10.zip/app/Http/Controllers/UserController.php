<?php

namespace App\Http\Controllers;

use App\Helpers\Service;
use App\Http\Resources\CardInfoResource;
use App\Http\Resources\NotificationResource;
use App\Http\Resources\PlansResource;
use App\Models\Config;
use App\Models\Notification;
use App\Models\Plan;
use App\Models\UserNotification;
use Illuminate\Http\Request;

class UserController extends Controller
{
    public function index(Request $request)
    {
        $information = Service::information(auth()->user()->name);
        return response()->json(['success' => true, 'data' => [
            'service_information' => $information,
            'notifications' => NotificationResource::collection(Notification::doesntHave('users')
                ->get())
        ]]);
    }

    public function checkNotification(Request $request, Notification $Id)
    {
        if (is_null($Id)) {
            return response()->json(['success' => false, 'message' => 'ID not found'], 400);
        }

        UserNotification::updateOrCreate(
            [
                'user_id' => auth()->user()->id,
                'notification_id' => $Id->id
            ],
            [
                'notification_id' => $Id->id
            ]
        );

        return response()->json(['success' => true, 'message' => 'Your request was successful.']);
    }

    public function plans(Request $request)
    {
        $plans = Plan::all();
        return response()->json(['success' => true, 'data' => PlansResource::collection($plans)]);
    }

    public function cardInfo(Request $request)
    {
        $cartInfo = Config::where('key', 'card')->firstOrFail();
        return response()->json(['success' => true, 'data' => new CardInfoResource($cartInfo)]);
    }
}
