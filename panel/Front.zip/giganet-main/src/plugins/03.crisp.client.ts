export default defineNuxtPlugin(async (nuxtApp) => {
    // window.$crisp = [];
    // window.CRISP_WEBSITE_ID = "195ebc60-fec0-4775-a630-178947e51187";

    // (function() {
    //     var d = document;
    //     var s = d.createElement("script");
    
    //     s.src = "https://client.crisp.chat/l.js";
    //     s.async = 1;
    //     d.getElementsByTagName("head")[0].appendChild(s);
    //   })();    
});